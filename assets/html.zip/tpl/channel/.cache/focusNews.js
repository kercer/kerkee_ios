/*TMODJS:{"version":2,"md5":"16ea4fcfd27426bdc1092566b96e0630"}*/
template('focusNews',function($data,$filename
/**/) {
'use strict';var $utils=this,$helpers=$utils.$helpers,$escape=$utils.$escape,link=$data.link,$each=$utils.$each,pics=$data.pics,value=$data.value,key=$data.key,title=$data.title,$out='';$out+='<div class="focusNews"> <a href="';
$out+=$escape(link);
$out+='" class=" markread"> ';
$each(pics,function(value,key){
$out+=' <img class="img" id="topFocusImg" src="';
$out+=$escape(value);
$out+='" data="';
$out+=$escape(value);
$out+='" style="background-image: url(';
$out+=$escape(value);
$out+=');"/> ';
});
$out+=' <b>';
$out+=$escape(title);
$out+='</b> </a> </div>';
return new String($out);
});