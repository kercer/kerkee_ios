/*TMODJS:{"version":6,"md5":"363d3abc95c8cf0f3719d1a79aa9ffd6"}*/
template('listView',function($data,$filename
/**/) {
'use strict';var $utils=this,$helpers=$utils.$helpers,$each=$utils.$each,articles=$data.articles,item=$data.item,index=$data.index,$escape=$utils.$escape,value=$data.value,key=$data.key,$out='';$out+='<div class="news"> ';
$each(articles,function(item,index){
$out+=' ';
if(item.newsType==3){
$out+=' ';
if(item.pics && item.pics.length >0){
$out+=' <div class="slice" id="';
$out+=$escape(item.newsId);
$out+='_3"> <a href="';
$out+=$escape(item.link);
$out+='"> ';
$each(item.pics,function(value,key){
$out+=' <img class="img" src="';
$out+=$escape(value);
$out+='"/> ';
});
$out+=' ';
if(item.isHasAudio==1 || item.isHasTv==1){
$out+=' <span class="tvTip"></span> ';
}
$out+=' <b>';
$out+=$escape(item.title);
$out+='</b> <div class="info"><span class="cmt"><i class="ii i3"></i><i class="cmtNum" data-id="';
$out+=$escape(item.newsId);
$out+='">';
$out+=$escape(item.commentNum);
$out+='</i></span><span class="time">';
$out+=$escape(item.media);
$out+='</span></div> </a> </div> ';
}else{
$out+=' <div class="slice noImgCls" id="';
$out+=$escape(item.newsId);
$out+='_6"> <a href="';
$out+=$escape(item.link);
$out+='"> <b>';
$out+=$escape(item.title);
$out+='</b> <div class="info"> <span class="cmt"> <i class="ii i3"></i> <i class="cmtNum" data-id="';
$out+=$escape(item.newsId);
$out+='">';
$out+=$escape(item.commentNum);
$out+='</i> </span> <span class="time">';
$out+=$escape(item.media);
$out+='</span> </div> </a> </div> ';
}
$out+=' ';
}else if(item.newsType==4){
$out+=' <div class="slice threeImgCls" id="';
$out+=$escape(item.newsId);
$out+='_4"> <a href="';
$out+=$escape(item.link);
$out+='"> <b>';
$out+=$escape(item.title);
$out+='</b> <div class="img3Div"> ';
$each(item.pics,function(value,key){
$out+=' <div><img class="img3" src="';
$out+=$escape(value);
$out+='"/></div> ';
});
$out+=' </div> <div class="info"> <span class="cmt"> <i class="ii i3"></i> <i class="cmtNum" data-id="44792422" style="opacity: 1;">';
$out+=$escape(item.commentNum);
$out+='</i> </span> <span class="picCount"><i class="ii i1"></i>';
$out+=$escape(item.listPicsNumber);
$out+='</span> <span class="time">';
$out+=$escape(item.media);
$out+='</span> </div> </a> </div> ';
}else if(item.newsType==6){
$out+=' <div class="slice noImgCls" id="';
$out+=$escape(item.newsId);
$out+='_2_6"> <a href="';
$out+=$escape(item.link);
$out+='"> <b>';
$out+=$escape(item.title);
$out+='</b> <div class="info"> <span class="cmt"> <i class="ii i3"></i> <i class="cmtNum" data-id="';
$out+=$escape(item.newsId);
$out+='">';
$out+=$escape(item.commentNum);
$out+='</i> </span> <span class="time">';
$out+=$escape(item.media);
$out+='</span> </div> </a> </div> ';
}
$out+=' ';
});
$out+=' </div>';
return new String($out);
});