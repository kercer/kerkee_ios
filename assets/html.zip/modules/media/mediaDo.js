/**
 * Created by jianhuang on 2015/3/28.
 */
define([
        'bridgeLib',
        'zepto',
        'api/nativeUI/widget',
        'api/client/clientInfo',
        'domReady!'
    ],

    function (bridgeLib, $,widget,clientInfo) {
        function MediaDo(){
            this.jsbc=jsBridgeClient;
            this.nativeCls="searchModules";
        }

        MediaDo.prototype.shoMedia=function(host){
            var t = this;
            var URL = host+'api/search/v5/search.go';
            var pageNo = 1;
            var keyWord = getQueryString('words');

            function requestMediaPublication(json, pageNo) {
                $.ajax({
                    url: URL,
                    data: {
                        rt: 'json',
                        pageNo: pageNo,
                        words: keyWord,
                        p1: json.p1,
                        pageSize: 20,
                        type: 30,
                        pid: json.pid,
                        token: json.token,
                        gid: json.gid,
                        apiVersion: json.apiVersion,
                        sid: json.sid,
                        u: json.u,
                        bid: json.bid
                    },
                    success: function (data) {
                        $('.loading').hide();
                        if (!data) {
                            $('#moreCon').hide();
                            return;
                        }
                        if (!!data) {
                            if (!data.resultList) {
                                $('#moreCon').hide();
                                return false;
                            }
                            var arrContent = data.resultList;
                            var mediaStr = '';
                            for (var i = 0; i < arrContent.length; i++) {
                                var starWidth = arrContent[i].starGradeAvg * 20 + '%';
                                var subedStr = '';
                                if (arrContent[i].isSubed == 0) {
                                    subedStr = '<p class="subscription j_subscription" data-sub="' + arrContent[i].newsId + '">订阅</p>';
                                } else if (arrContent[i].isSubed == 1) {
                                    subedStr = '<p class="subscription">已订</p>';
                                }

                                var href=arrContent[i]["pics"] ? arrContent[i]["pics"][0]:"http://cache.k.sohu.com/img8/wb/iospicon/2015/01/27/b1fcbf99673d6e0d904375db7fd037ceios.png";

                                mediaStr += ['<div class="mediaContent commonContent">',
                                    '<a href="' + arrContent[i].link + '" class="mediaContentLink clear">',
                                    '<div class="mediaLogoContainer left">',
                                    '<img src="' + href + '" alt="" class="mediaLogo"/>',
                                    '</div>',
                                    '<div class="mediaDetail left">',
                                    '<p class="mediaName">' + markKeyWord(arrContent[i].title, keyWord) + '</p>',
                                    '<div class="starContainer"><b style="width:' + starWidth + '"></b></div>',
                                    '<p class="readerNum">' + arrContent[i].countShowText + '</p>',
                                    '</div>',
                                    '</a>',
                                    subedStr,
                                    '</div>'].join('');
                            }
                            $('.content').append(mediaStr);
                            if (arrContent.length < 20) {
                                $('#moreCon').hide();
                            } else {
                                $('#moreCon').show();
                            }
                        }
                    }
                });
            }

            clientInfo.getRequestParam(function (data) {
                var dataJson = data;
                requestMediaPublication(dataJson, pageNo);
            });

            //获取url参数
            function getQueryString(name) {
                var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
                var r = window.location.search.substr(1).match(reg);
                if (r != null) {
                    return decodeURIComponent(r[2]);
                }
                return null;
            }

            //点击订阅
            $(document).on('touchstart', '.j_subscription', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var _this = $(event.target);
                _this.addClass("color_gray");
                return false;
            }).on('touchend','.j_subscription',function(e){
                e.preventDefault();
                e.stopPropagation();
                var _this = $(event.target);
                _this.removeClass("color_gray");
                var subId = $(this).data('sub')+"";
                t.addSubscribe(subId, function (data) {
                    if (data.state == 0) {
                        _this.closest(".j_subscription").removeClass('j_subscription').html('已订');
                    }
                });
                return false;
            });;

            //标记关键字
            function markKeyWord(str, keyWord) {
                var reg = new RegExp(keyWord, 'g');
                return str = str.replace(reg, function (s) {
                    var tmp = '';
                    for (var i = 0; i < s.length; i++) {
                        tmp = '<span class="hot">' + s + '</span>';
                    }
                    return tmp;
                });
            }

            /*------加载更多新闻--------*/
            var Viewer = {
                getTopHeight: function () {
                    return {
                        pTop: window.pageYOffset || document.documentElement.scrollTop,
                        pHeight: document.documentElement.clientHeight || window.innerHeight
                    };
                },

                /**
                 * 当页面滚动到可视区域时处理某事件
                 * @param ele
                 * @param options {iScreens:2,pTop:100,pHeight:200，handle:function(){}}
                 */
                inViewPort: function (ele, options) {
                    var me = this,
                        iScreens = 1, //1=当前屏;2=下一屏
                        pTop = options.pTop, //scrollTop
                        pHeight = options.pHeight, //clientHeight
                        pBottom;

                    if (options.iScreens) {
                        iScreens = options.iScreens;
                    }

                    if (!pTop) {
                        pTop = me.getTopHeight().pTop;
                    }

                    if (!pHeight) {
                        pHeight = me.getTopHeight().pHeight;
                    }

                    pBottom = pTop + pHeight * iScreens;

                    var fn = function () {
                        if (typeof(options.handle) == "function") {
                            options.handle();
                        }
                    };

                    if (ele) {
                        if (ele.getBoundingClientRect) {
                            var eleTop = ele.getBoundingClientRect().top + pTop,
                                eleBottom = eleTop + ele.clientHeight;
                            //可视区域范围(eleTop > pTop && eleTop < pBottom) && (eleBottom > pTop && eleBottom < pBottom)
                            //浏览过的视图范围 eleTop>=0 && pBottom-eleBottom>=0
                            if ((eleTop > pTop && eleTop < pBottom) && (eleBottom > pTop && eleBottom < pBottom)) {
                                fn();
                            }

                        } else {
                            fn();
                        }
                    }
                }
            };

            // 触底加载下一页
            function turnPage() {
                pageNo++;
                clientInfo.getRequestParam(function (data) {
                    var dataJson = data;
                    requestMediaPublication(dataJson, pageNo);
                });
            }

            function autoLoad() {
                var pPos = Viewer.getTopHeight();
                Viewer.inViewPort($('#moreCon'), {
                    iScreens: 1,
                    pTop: pPos.pTop,
                    pHeight: pPos.pHeight + 200,
                    handle: function () {
                        turnPage();
                    }
                });
            }

            addEvent(window, 'scroll', function () {
                if (arguments.callee.timer) clearTimeout(arguments.callee.timer);
                arguments.callee.timer = setTimeout(function () {
                    autoLoad();
                }, 400); //两次scroll事件触发之间最小的事件间隔
            });

            //回到顶部
            function toTop() {
                //J_bottomSection
                var oBtn = document.getElementById('goTop');
                var h = window.screen.height;
                addEvent(window, 'scroll', function () {
                    var scrollT = document.documentElement.scrollTop || document.body.scrollTop;
                    if (scrollT > 3 * h) {
                        oBtn.style.display = 'block';
                    } else {
                        oBtn.style.display = 'none';
                    }
                });
                var timer = null;
                oBtn.onclick = function () {
                    clearInterval(timer);
                    var count = Math.floor(500 / 30);
                    var start = document.documentElement.scrollTop || document.body.scrollTop;
                    var dis = 0 - start;

                    var n = 0;
                    timer = setInterval(function () {
                        n++;
                        var a = 1 - n / count;
                        var cur = start + dis * (1 - a * a * a);
                        document.documentElement.scrollTop = document.body.scrollTop = cur;
                        if (n == count) {
                            clearInterval(timer);
                        }
                    }, 30);
                };
            }

            toTop();
            //事件绑定
            function addEvent(obj, sEv, fn) {
                if (obj.addEventListener) {
                    obj.addEventListener(sEv, fn, false);
                } else {
                    obj.attachEvent('on' + sEv, fn);
                }
            }
        };

        MediaDo.prototype.render=function() {
            var t=this;
            clientInfo.getHost(function(host){
                var host=host.info;
                t.shoMedia(host);
            });
        };

        MediaDo.prototype._callNative=function(clz,method, args, callback){
           jsBridgeClient.invoke(clz,method, args, callback);
        };


        MediaDo.prototype.addSubscribe=function(subId,callback){
            var t=this;
            this._callNative(t.nativeCls,"addSubscribe",{
                "subId":subId
            },callback);
        };

        // MediaDo.prototype.testNative=function(){
        //     var t=this;
        //     $("#loadParam").on("tap",function(){
        //         clientInfo.getRequestParam(function(data){
        //             alert(JSON.stringify(data));
        //             jsonData=data;
        //         });

        //     });

        //     $("#searchHotWord").on("tap",function(){
        //         t.searchHotWord(function(data){
        //             alert(data);
        //             console.log(data);
        //         });
        //     });

        //     $("#updateSearchWord").on("tap",function(){
        //         t.updateSearchWord('liyong');
        //     });

        //     $("#addSubscribe").on("tap",function(){
        //         t.addSubscribe(12345,function(data){
        //             console.log(data);
        //         });
        //     });

        //     // $("#testDialog").on("tap",function(){
        //     //    widget.alertDialog("title","cont",function(){
        //     //         alert("clicked");
        //     //    });
        //     // });

        // };


        MediaDo.prototype.init=function(){
            var t=this;
            this.jsbc.onDeviceReady(function () {
                t.render();
                // t.testNative();
            });
        };

        return new MediaDo();
    });