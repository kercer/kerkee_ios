/**
 * Created by jianhuang on 2015/3/28.
 */
define([
        'bridgeLib',
        'zepto',
        'api/client/clientInfo',
        'domReady!'
    ],

    function (bridgeLib, $,clientInfo) {
        function SearchDo(){
            this.jsbc=jsBridgeClient;
            this.nativeCls="searchModules";
        }

        SearchDo.prototype.render=function(){
            var t=this;
            clientInfo.getHost(function(host){
                var host=host.info;
                t.showSearch(host);
            });
        };

        SearchDo.prototype.showSearch=function(host){
            var URL=host+'api/search/v5/search.go';
            var t=this;
            //获取关键词
            t.searchHotWord(function(data){
                var wordJson=JSON.parse(data);
                var getKeyWord=wordJson.keyword;
                reloadHtml(getKeyWord); // 渲染页面
            });
            
            function reloadHtml(keyWord){
                $('.content').fadeTo('slow').html('');
                var pageNo=1;
                clientInfo.getRequestParam(function(data){
                    var dataJson=data;
                    requestData(dataJson,0,12);
                });
                $('#moreCon').hide();
                $('.content').fadeIn('slow');

                function requestData(json,type,pageSize){
                    $.ajax({
                        url:URL,
                        data:{
                            rt:'json',
                            pageNo:pageNo,
                            words:keyWord,
                            p1:json.p1,
                            pageSize:pageSize,
                            type:type,
                            pid:json.pid,
                            token:json.token,
                            gid:json.gid,
                            apiVersion:json.apiVersion,
                            sid:json.sid,
                            u:json.u,
                            bid:json.bid
                        },
                        dataType:"json",

                        error:function(){
                            alert("error");
                        },

                        success:function(data){
                            $('.loading').hide();
                            if(!data){
                                $('.searchno').show();
                                $('#moreCon').hide();
                                return;
                            }
                            if(!!data){
                                if(!data.resultList){
                                    if(pageNo==1){
                                        $('.searchno').show();
                                    }
                                    $('#moreCon').hide();
                                    return false;
                                }
                                var arrContent=data.resultList;
                                var newsListStr='';
                                for(var i=0;i<arrContent.length;i++){
                                    if(arrContent[i].newsType==50){
                                        var channelStr='';
                                        channelStr=['<div class="channel">',
                                                    '<h3 class="commonTitle">频道</h3>',
                                                    '<a href="'+arrContent[i].link+'" class="channelContent clear commonContent">',
                                                    '<img src="../../images/channeltest.png" alt="" class="channelLogo left">',
                                                    '<p class="channelText left">'+arrContent[i].title+'</p>',
                                                    '</a>',
                                                    '</div>'].join('');
                                        $('.content').append(channelStr);
                                    }

                                    if(arrContent[i].newsType==30){
                                        var starWidth=arrContent[i].starGradeAvg*20+'%';
                                        var subedStr='';
                                        var mediaStr='';
                                        var moreMediaStr='';
                                        if(arrContent[i].isSubed==0){
                                            subedStr='<p class="subscription j_subscription" data-sub="'+arrContent[i].newsId+'">订阅</p>';
                                        }else if(arrContent[i].isSubed==1){
                                            subedStr='<p class="subscription">已订</p>';
                                        }
                                        if(data.subTotal>1){
                                            moreMediaStr='<a href="../media/media.html?words='+encodeURIComponent(keyWord)+'" class="moreMedia">查看全部'+data.subTotal+'个相关媒体刊物<b></b></a>';
                                        }else{
                                            moreMediaStr='';
                                        }
                                        mediaStr=['<div class="mediaPublication">',
                                                '<h3 class="commonTitle mediaPublicationTitle">媒体刊物</h3>',
                                                '<div class="mediaContent commonContent">',
                                                '<a href="'+arrContent[i].link+'" class="mediaContentLink clear">',
                                                '<div class="mediaLogoContainer left">',
                                                '<img src="'+arrContent[i].pics[0]+'" alt="" class="mediaLogo">',
                                                '</div>',
                                                '<div class="mediaDetail left">',
                                                '<p class="mediaName">'+markKeyWord(arrContent[i].title,keyWord)+'</p>',
                                                '<div class="starContainer"><b style="width:'+starWidth+'"></b></div>',
                                                '<p class="readerNum">'+arrContent[i].countShowText+'</p>', 
                                                '</div>',
                                                '</a>',
                                                subedStr,
                                                '</div>',
                                                moreMediaStr,
                                                '</div>'].join('');
                                        $('.content').append(mediaStr);
                                    }

                                    if(arrContent[i].newsType==3){
                                        newsListStr+=newsList(arrContent[i]);
                                    }

                                }
                                if(pageNo==1){
                                    var newsContentStr=['<div class="newsContainer">',
                                            '<h3 class="newsTitle commonTitle">新闻</h3>',
                                            '<div class="newsContent commonContent">',
                                            newsListStr, 
                                            '</div>',
                                            '</div>'].join('');
                                    $('.content').append(newsContentStr);
                                }else if(pageNo>1){
                                    $('.newsContent').append(newsListStr);
                                }

                                //添加热词
                                if(data.hotwords.length!=0){
                                    var hotWordsConStr='';
                                    for(var i=0;i<data.hotwords.length;i++){
                                        hotWordsConStr+='<p class="left">'+data.hotwords[i]+'</p>';
                                    }
                                    var hotWordsStr=['<div class="hotWord">',
                                                    '<h3 class="hotWordTitle">大家还在搜</h3>',
                                                    '<div class="hotWordContainer clear">',
                                                    hotWordsConStr,
                                                    '</div>',
                                                    '</div>'].join('');
                                    $('.newsContent').append(hotWordsStr);
                                }         
                                $('#moreCon').show();
                                //新闻title固定在顶部
                                $(document).on('scroll',function(){
                                    var scrollT=$('body').scrollTop();

                                    if(scrollT<$('.newsTitle').offset().top){
                                        $('.newsTitleReplace').hide();
                                    }else{
                                        $('.newsTitleReplace').show();
                                    }
                                });
                            }
                        }
                    });
                }

                function newsList(arrContent){
                    var picStr='';
                        var obj=arrContent;
                        var exclusiveStr='';
                        if(!!obj.newsMark){
                            exclusiveStr='<b class="right" style="color:red;">独家</b>';
                        }else{
                            exclusiveStr='';
                        }
                        if(!obj.pics){
                            picStr=['<a href="'+obj.link+'" class="newsContentContainer clear">',
                                    '<div class="newsContentTitle">',
                                    '<p class="newsText">'+markKeyWord(obj.title,keyWord)+'</p>',
                                    '<div class="iconAndSource clear">',
                                    '<span class="left">'+obj.commentNum+'</span><b class="left">'+obj.media+'</b>',
                                    exclusiveStr,
                                    '</div>',
                                    '</div>',
                                    '</a>'].join('');
                        }else if (obj.pics.length===1) {
                            picStr=['<a href="'+obj.link+'" class="newsContentContainer clear">',
                                    '<i class="newsContentPic left">',
                                    '<img src="'+obj.pics[0]+'" alt="">',
                                    '</i>',
                                    '<div class="newsContentTitle">',
                                    '<p class="newsText picText">'+markKeyWord(obj.title,keyWord)+'</p>',
                                    '<div class="iconAndSource clear">',
                                    '<span class="left">'+obj.commentNum+'</span><b class="left">'+obj.media+'</b>',
                                    exclusiveStr,
                                    '</div>',
                                    '</div>',
                                    '</a>'].join('');
                        }else if (obj.pics.length>1) {
                            picStr=['<a href="'+obj.link+'" class="newsContentContainer">',
                                    '<p class="newsText">'+markKeyWord(obj.title,keyWord)+'</p>',
                                    '<div class="newsContentMorePicContainer clear">',
                                    '<i class="newsContentMorePic left">',
                                    '<img src="'+obj.pics[0]+'" alt="">',
                                    '</i>',
                                    '<i class="newsContentMorePic left">',
                                    '<img src="'+obj.pics[1]+'" alt="">',
                                    '</i>',
                                    '<i class="newsContentMorePic left">',
                                    '<img src="'+obj.pics[2]+'" alt="">',
                                    '</i>',
                                    '</div>',
                                    '<div class="iconAndSource clear">',
                                    '<span class="left">'+obj.commentNum+'</span><b class="picIcon left">'+obj.listPicsNumber+'</b>',
                                    exclusiveStr,
                                    '</div>',
                                    '</a>'].join('');
                        }
                    return picStr;  
                }

                /*------加载更多新闻--------*/
                var Viewer = {
                    getTopHeight: function() {
                        return {
                            pTop: window.pageYOffset || document.documentElement.scrollTop,
                            pHeight: document.documentElement.clientHeight || window.innerHeight
                        };
                    },

                    /**
                     * 当页面滚动到可视区域时处理某事件
                     * @param ele
                     * @param options {iScreens:2,pTop:100,pHeight:200，handle:function(){}}
                     */
                    inViewPort: function(ele, options) {
                        var me = this,
                            iScreens = 1, //1=当前屏;2=下一屏
                            pTop = options.pTop, //scrollTop
                            pHeight = options.pHeight, //clientHeight
                            pBottom;

                        if (options.iScreens) {
                            iScreens = options.iScreens;
                        }

                        if (!pTop) {
                            pTop = me.getTopHeight().pTop;
                        }

                        if (!pHeight) {
                            pHeight = me.getTopHeight().pHeight;
                        }

                        pBottom = pTop + pHeight * iScreens;

                        var fn = function() {
                            if (typeof(options.handle) == "function") {
                                options.handle();
                            }
                        };

                        if (ele) {
                            if (ele.getBoundingClientRect) {
                                var eleTop = ele.getBoundingClientRect().top + pTop,
                                    eleBottom = eleTop + ele.clientHeight;
                                //可视区域范围(eleTop > pTop && eleTop < pBottom) && (eleBottom > pTop && eleBottom < pBottom)
                                //浏览过的视图范围 eleTop>=0 && pBottom-eleBottom>=0
                                if ((eleTop > pTop && eleTop < pBottom) && (eleBottom > pTop && eleBottom < pBottom)) {
                                    fn();
                                }

                            } else {
                                fn();
                            }
                        }
                    }
                };

                // 触底加载下一页
                function turnPage() {
                    pageNo++;
                    clientInfo.getRequestParam(function(data){
                        var dataJson=data;
                        requestData(dataJson,3,10);
                    });
                }

                function autoLoad() {
                    var pPos = Viewer.getTopHeight();
                    Viewer.inViewPort($('#moreCon'), {
                        iScreens: 1,
                        pTop: pPos.pTop,
                        pHeight: pPos.pHeight +200,
                        handle: function() {
                            turnPage();
                        }
                    });
                }

                addEvent(window, 'scroll', function() {
                    if (arguments.callee.timer) clearTimeout(arguments.callee.timer);
                    arguments.callee.timer = setTimeout(function() {
                        autoLoad();
                    }, 400); //两次scroll事件触发之间最小的事件间隔
                });

            }


            //回到顶部
            function toTop() {
                //J_bottomSection
                var oBtn = document.getElementById('goTop');
                var h = window.screen.height;
                addEvent(window, 'scroll', function() {
                    var scrollT = document.documentElement.scrollTop || document.body.scrollTop;
                    if (scrollT > 3 * h) {
                        oBtn.style.display = 'block';
                    } else {
                        oBtn.style.display = 'none';
                    }
                });
                var timer = null;
                oBtn.onclick = function() {
                    clearInterval(timer);
                    var count = Math.floor(500 / 30);
                    var start = document.documentElement.scrollTop || document.body.scrollTop;
                    var dis = 0 - start;

                    var n = 0;
                    timer = setInterval(function() {
                        n++;
                        var a = 1 - n / count;
                        var cur = start + dis * (1 - a * a * a);
                        document.documentElement.scrollTop = document.body.scrollTop = cur;
                        if (n == count) {
                            clearInterval(timer);
                        }
                    }, 30);
                };
            }
            toTop();
            //事件绑定
            function addEvent(obj, sEv, fn) {
                if (obj.addEventListener) {
                    obj.addEventListener(sEv, fn, false);
                } else {
                    obj.attachEvent('on' + sEv, fn);
                }
            }
            //点击订阅
            $('body').on('touchstart','.j_subscription',function(event){
                event.preventDefault();
                event.stopPropagation();
                var _this = $(event.target);
                _this.addClass("color_gray");
                return false;
            }).on('touchend','.j_subscription',function(event){
                event.preventDefault();
                event.stopPropagation();
                var _this = $(event.target);
                _this.removeClass("color_gray");
                var subId=$(this).data('sub')+"";
                t.addSubscribe(subId,function(data){
                    if(data.state==0){
                        _this.closest(".j_subscription").removeClass('j_subscription').html('已订');
                    }
                });
                return false;
            });

            //标记关键字
            function markKeyWord(str,keyWord){
                var reg=new RegExp(keyWord,'g');
                return newStr=str.replace(reg,function(s){
                    var tmp='';
                    for(var i=0;i<s.length;i++){
                        tmp='<span class="hot">'+s+'</span>';
                    }
                    return tmp;
                });
            }

            //点击热词重写页面
            $('body').on('tap','.hotWordContainer p',function(){
                $('.newsTitleReplace').hide();
                $(document).off('scroll');
                var hotKeyWords=$(this).html();
                t.updateSearchWord(hotKeyWords);
                reloadHtml(hotKeyWords);
            });    
        };

        SearchDo.prototype._callNative=function(clz,method, args, callback){
           jsBridgeClient.invoke(clz,method, args, callback);
        };

        SearchDo.prototype.searchHotWord=function(callback){
            var t=this;
            this._callNative(t.nativeCls,"searchHotWord",{
                "searchHotWord":"searchHotWord"
            },callback);
        };

        SearchDo.prototype.updateSearchWord=function(searchword){
            var t=this;
            this._callNative(t.nativeCls,"updateSearchWord",{
                "searchword":searchword
            });
        };

        SearchDo.prototype.addSubscribe=function(subId,callback){
            var t=this;
            this._callNative(t.nativeCls,"addSubscribe",{
                "subId":subId
            },callback);
        };

        // SearchDo.prototype.testNative=function(){
        //     var t=this;
        //     $("#loadParam").on("tap",function(){
        //         clientInfo.getRequestParam(function(data){
        //             alert(JSON.stringify(data));
        //             jsonData=data;
        //         });

        //     });

        //     $("#searchHotWord").on("tap",function(){
        //         t.searchHotWord(function(data){
        //             alert(data);
        //             console.log(data);
        //         });
        //     });

        //     $("#updateSearchWord").on("tap",function(){
        //         t.updateSearchWord('liyong');
        //     });

        //     $("#addSubscribe").on("tap",function(){
        //         t.addSubscribe(12345,function(data){
        //             console.log(data);
        //         });
        //     });

        //     // $("#testDialog").on("tap",function(){
        //     //    widget.alertDialog("title","cont",function(){
        //     //         alert("clicked");
        //     //    });
        //     // });

        // };


        SearchDo.prototype.init=function(){
            var t=this;
            this.jsbc.onDeviceReady(function () {
                t.render();
                // t.testNative();
            });
        };

        return new SearchDo();
    });