/**
 * Created by huangjian on 15-3-25.
 */
define(["zepto", "template"], function ($, template) {

    var Utils = {

        reloadPage:function(){
            var html='<div id="reloadPage_debug" class="debug-page">R</div>';
            $("body").append(html);
        },

        parseTemplate: function (id, artmpl, data) {
            var objE = document.createElement("div");
            var timesup = new Date().getTime();
            objE.id = "artmplBox" + timesup;
            var template_id = "artmpl_" + id;
            objE.innerHTML = '<script type="text/html" id="' + template_id + '">' + artmpl + '</script>';
            objE.style.display = "none";
            document.body.appendChild(objE);
            var template_cont = template(template_id, data);
            document.body.removeChild(objE);
            return template_cont;
        },

        compileTempl: function (template_id, data) {
            var template_cont = template(template_id, data);
            return template_cont;
        },

        getLocalTime:function(unixtime,pattern){
            //日期格式初始化
            Date.prototype.format = function(pattern){
                var pad = function (source, length) {
                    var pre = "",
                        negative = (source < 0),
                        string = String(Math.abs(source));

                    if (string.length < length) {
                        pre = (new Array(length - string.length + 1)).join('0');
                    }

                    return (negative ?  "-" : "") + pre + string;
                };

                if ('string' != typeof pattern) {
                    return this.toString();
                }

                var replacer = function(patternPart, result) {
                    pattern = pattern.replace(patternPart, result);
                }

                var year    = this.getFullYear(),
                    month   = this.getMonth() + 1,
                    date2   = this.getDate(),
                    hours   = this.getHours(),
                    minutes = this.getMinutes(),
                    seconds = this.getSeconds();

                replacer(/yyyy/g, pad(year, 4));
                replacer(/yy/g, pad(parseInt(year.toString().slice(2), 10), 2));
                replacer(/MM/g, pad(month, 2));
                replacer(/M/g, month);
                replacer(/dd/g, pad(date2, 2));
                replacer(/d/g, date2);

                replacer(/HH/g, pad(hours, 2));
                replacer(/H/g, hours);
                replacer(/hh/g, pad(hours % 12, 2));
                replacer(/h/g, hours % 12);
                replacer(/mm/g, pad(minutes, 2));
                replacer(/m/g, minutes);
                replacer(/ss/g, pad(seconds, 2));
                replacer(/s/g, seconds);

                return pattern;
            };
            var timestr = new Date(parseInt(unixtime));
            var datetime = timestr.format(pattern);
            return datetime;
        },

        /*读取查询字符串*/
        getQueryString:function(name){
            var params = location.search.substring(1).toLowerCase();
            var paramList = [];
            var param = null;
            var parami;
            if (params.length > 0) {
                if (params.indexOf("&") >= 0) {
                    paramList = params.split("&");
                } else {
                    paramList[0] = params;
                }
                for (var i = 0, listLength = paramList.length; i < listLength; i++) {
                    parami = paramList[i].indexOf(name + "=");
                    if (parami >= 0) {
                        param = paramList[i].substr(parami + (name + "=").length);
                    }
                }
            }
            return param;
        },

        query2obj:function(url){
            var obj={};
            var reg=new RegExp("^"+"http");
            var queryString;

            if(reg.test(url)){
                queryString=url.substring(url.indexOf("?")+1,url.length);
            }else{
                queryString=url;
            }

            var _arr=queryString.split("&"),
                len=_arr.length;

            for (var i = 0; i < len; i++) {
                var item=_arr[i].split('=');
                var key=item[0];
                var value=item[1];
                obj[key]=value;
            }
            return obj;
        },

        /*随机数*/
        getRandomNum: function (min, max) {
            var range = max - min;
            var rand = Math.random();
            return (min + Math.round(rand * range));
        },

        sendData:function(type,url,data,successs,before,error,complate,dataType){
            $.ajax({
                type:type,
                url:url,
                timeout:200000,
                data:data,
                cache:false,
                dataType:dataType||"json",
                beforeSend:before||function(){

                },
                success:successs,
                error:error||function(){

                },
                complate:complate||function(){

                }
            });
        },

        /*scrollView*/
        scrollViewer: {
            getTopHeight: function () {
                return {
                    pTop: window.pageYOffset || document.documentElement.scrollTop,
                    pHeight: document.documentElement.clientHeight || window.innerHeight
                };
            },
            /**
             * 当页面滚动到可视区域时处理某事件
             * @param ele
             * @param options {iScreens:2,pTop:100,pHeight:200，handle:function(){}}
             */
            inViewPort: function (ele, options) {
                var me = this,
                    iScreens = 1, //1=当前屏;2=下一屏
                    pTop = options.pTop, //scrollTop
                    pHeight = options.pHeight, //clientHeight
                    pBottom,
                    $document=$(document),
                    $window=$(window);

                if (options.iScreens) {
                    iScreens = options.iScreens;
                }

                if (!pTop) {
                    pTop = me.getTopHeight().pTop;
                }

                if (!pHeight) {
                    pHeight = me.getTopHeight().pHeight;
                }

                pBottom = pTop + pHeight * iScreens;

                var fn = function () {
                    if (typeof(options.handle) == "function") {
                        options.handle();
                    }
                };

                if (ele) {
                    if (ele.getBoundingClientRect) {
                        var eleTop = ele.getBoundingClientRect().top + pTop,
                            eleBottom = eleTop + ele.clientHeight;
                        //可视区域范围(eleTop > pTop && eleTop < pBottom) && (eleBottom > pTop && eleBottom < pBottom)
                        //浏览过的视图范围 eleTop>=0 && pBottom-eleBottom>=0
                        if ((eleTop > pTop && eleTop < pBottom) && (eleBottom > pTop && eleBottom < pBottom)) {
                            fn();
                        }
                    } else {
                        var scrollPos =$window.scrollTop();
                        var totalHeight = parseFloat($window.height()) + parseFloat(scrollPos);
                        if ((($document.height() - 60) <= totalHeight)) {
                            fn();
                        }
                    }
                }
            },

            create:function(id,callBack){
                var pPos = Utils.scrollViewer.getTopHeight();
                Utils.scrollViewer.inViewPort($(id), {
                    iScreens: 1,
                    pTop: pPos.pTop,
                    pHeight: pPos.pHeight + 200,
                    handle: function () {
                        callBack();
                    }
                });
            }
        },

        // 设置夜间模式 1夜间  0日间
        chgMode:function chgMode(num) {
            var $ele = $("#myMode");
            if ($ele.size()>0) {
                if ($ele.hasClass("Mode1")) {
                    if (!num) {
                        $ele.removeClass("Mode1");
                    }
                    return;
                } else {
                   if(num==1){
                       $ele.addClass("Mode1");
                   }else{
                       $ele.removeClass("Mode1")
                   }
                }
            }
        },

        //onload 时检测是否是夜间模式  解决安卓打包情况下夜间与日间模式的切换
        checkIfNight:function () {
            if (Utils.getQueryString("mode") == "1") {
                Utils.chgMode(1);
            } else {
                Utils.chgMode(0);
            }
        },

        // 设置无图模式 1无图  0有图
        chgImgMode:function chgMode(num) {
            var ele = document.getElementById("myMode");
            if (ele) {
                if ($(ele).hasClass() == "noImgMode") {
                    if (!num) {
                        ele.className = "";
                    }
                    return;
                } else {
                    ele.className = num == 1 ? "noImgMode" : "";
                }
            }
        },

        //检测是否为无图模式
        checkImgMode:function () {
            var imgMode="";
            if (Utils.getQueryString("imgs") == "1") {
                Utils.chgImgMode(1);
            } else {
                Utils.chgImgMode(0);
            }
        }

    };
    return Utils;
});
