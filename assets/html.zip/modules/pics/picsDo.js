/**
 * Created by jianhuang on 2015/3/28.
 */
define([
        'bridgeLib',
        'zepto',
        'api/client/clientUI',
        'api/client/clientInfo',
        'pics/picsNative',
        'helper/util',
        //自匹配无串参项
        'domReady!'
    ],

    function (bridgeLib, $,clientUI,clientInfo,picsNative,util) {

        function PicsDo() {
            this.num = 20;
            this.page = 1;
            this.shareContent = "";
            this.shareRead = null;
            this.url = "";
            this.request_param = {};
            this.loadingIcon = $("#pageloader");
            this.termView = $("#termView");
            this.loadingPage = $('#loading');
            this.focus = "";
            this.timer = null;
            this.html = "";
            this.cursor=-1;
        }

        PicsDo.prototype.nativeCallPage = function () {
            var t = this;
            //分享页面
            window.shareChannelPage = function (msg) {
                var title = t.shareRead.title,
                    content = t.shareContent,
                    link = t.shareContent.split(" ")[1],
                    icon = t.shareRead.pics;
                picsNative.sendShareInfo(title, content, link, icon);
            };

            // 设置夜间模式 1夜间  0日间
            window.changeReadMode = function (num) {
                util.chgMode(num);
            };

            // 设置有图像模式 1无图  0有图
            window.changeImgMode = function (num) {
                util.chgImgMode(num);
            };
        }

        /*native接口通信*/
        PicsDo.prototype.renderPage = function () {
            var t = this;

            //检测是否为夜间模式
            util.checkIfNight();

            //检测是否为无图模式
            util.checkImgMode();

            clientInfo.getRequestParam(function(param){
                picsNative.getChannelInfo(function (data) {
                    t.url ="http://onlinetestapi.k.sohu.com/api/photos/listInChannel.go?rt=json&channelId=47&pageSize=20&pageNo=1&offset=-1&p1=NTk0NDgzNjMxMTY2MzE2MTQ0Nw%3D%3D&gid=02ffff110611118bce83f5a21bd814a1a7c22c2fd44308&pid=-1"; //data.url;
                    t.request_param = util.query2obj(t.url);
                    t.request_param.p1=param.p1;
                    t.request_param.gid=param.gid;
                    t.request_param.pid=param.pid;
                    t.loadData(t.page, t.num, t.cursor);
                });
            });
        };

        PicsDo.prototype.parseNewsData = function (data, type) {
            var newsHtml;
            if (type == "news") {
                newsHtml = util.compileTempl("listView", data);
            } else if (type == "focus") {
                newsHtml = util.compileTempl("focusNews", data);
            }else if(type=="noImg"){
                newsHtml = util.compileTempl("noImgMode", data);
            }
            return newsHtml;
        };

        PicsDo.prototype.loadData = function (page, num ,cursor) {
            var t = this;
            var item = t.request_param;
            var url= t.url.substring(0,t.url.indexOf("?"));
            var params = {
                rt: "json",
                channelId: item.channelId,
                pageSize: num,
                pageNo: page,
                offset: cursor,
                p1:item.p1,
                gid:item.gid,
                pid:item.pid
            };

            console.log(params);

            util.sendData("get", url, params, function (data) {

                t.loadingPage.addClass("displayNone");

                if (data) {
                    if (data.shareContent) {
                        t.shareContent = data.shareContent;
                    }

                    if (data.shareRead) {
                        t.shareRead = data.shareRead;
                    }

                    if (data.news && data.news.length > 0) {
                        if (t.page == 1) {
                            if (data.news[0].newsType == 1) {
                                var _focusData = {
                                    "news": [
                                        data.news[0]
                                    ]
                                };
                                t.html += t.parseNewsData(_focusData, "focus");
                            }
                            t.html += t.parseNewsData(data, "news");
                            t.termView.html(t.html);
                        } else {
                            t.html = t.parseNewsData(data, "news");
                            t.termView.append(t.html);
                        }
                        t.cursor=data.offset;
                        t.page++;
                        t.loadingIcon.removeClass("displayNone");
                    }else{
                        clientUI.clientToast("没有更多的数据了哦!");
                        t.loadingIcon.addClass("displayNone");
                    }
                }else{
                    clientUI.clientToast("没有更多的数据了哦!");
                }
            }, function () {

            }, function (xhr, textStatus, errorThrown) {
                clientUI.clientToast("网络好像出现问题了","warn");
                console.log("<section>" + xhr.status + "</section>");
                console.log("<section>" + xhr.readyState + "</section>");
                console.log("<section>" + textStatus + "</section>");
            }, function () {
                t.loadingPage.addClass("displayNone");
            });
        };

        PicsDo.prototype.bindEvent = function () {
            var t = this;
            //滚动屏幕加载数据
            $(window).on('scroll', function () {
                if (arguments.callee.timer) {
                    clearTimeout(arguments.callee.timer);
                }
                arguments.callee.timer = setTimeout(function () {
                    util.scrollViewer.create("#pageloader", function () {
                        t.loadData(t.page, t.num,t.cursor);
                    });
                }, 600);
            });
        };

        PicsDo.prototype.init = function () {
            var t = this;
            jsBridgeClient.onDeviceReady(function () {
                t.nativeCallPage();
                t.renderPage();
                t.bindEvent();
            });
        };

        return new PicsDo();
    });