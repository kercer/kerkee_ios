/**
 * Created by huangjian on 15-4-2.
 */
define(["bridgeLib"],function(bridgeLib){
    function picsNative(){
        this.author='jk';
        this.version="1.0";
        this.jsbc=jsBridgeClient;
        this.nativeCls="channelModule";
    }

    /*
     * @desc 获取当前频道预览的服务请求信息
     * @param  {Function} callback
     * @result {Object}
     */
    picsNative.prototype.getChannelInfo=function(callback){
        var t=this;
        t.jsbc.invoke(t.nativeCls,"getChannelInfo",{
            "info":"getChannelInfo"
        },callback);
    }

    /*
     * @desc 发送当前预览频道的分享信息
     * @param  {String} title
     * @param  {String} content
     * @param  {String} link
     * @param  {String} icon
     */
    picsNative.prototype.sendShareInfo=function(title,content,link,icon){
        var t=this;
        t.jsbc.invoke(t.nativeCls,"sendShareInfo",{
            "title":title,
            "content":content,
            "link":link,
            "icon":icon
        });
    };

    return new picsNative();
});