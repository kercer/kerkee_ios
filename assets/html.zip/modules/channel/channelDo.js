/**
 * Created by jianhuang on 2015/3/28.
 */
define([
        'bridgeLib',
        'zepto',
        'api/client/clientUI',
        'api/client/clientInfo',
        'channel/channelNative',
        'helper/util',
        //自匹配无串参项
        'domReady!'
    ],

    function (bridgeLib, $,clientUI,clientInfo,channelNative,util) {

        function ChannelDo() {
            this.num = 20;
            this.page = 1;
            this.shareContent = "";
            this.shareRead = null;
            this.url = "";
            this.request_param = {};
            this.loadingIcon = $("#pageloader");
            this.termView = $("#termView");
            this.loadingPage = $('#loading');
            this.focus = "";
            this.timer = null;
            this.html = "";
            this.cursor=0;
        }

        ChannelDo.prototype.nativeCallPage = function () {
            var t = this;
            //分享页面
            window.shareChannelPage = function (msg) {
                var title = t.shareRead.title,
                    content = t.shareContent,
                    link = t.shareContent.split(" ")[1],
                    icon = t.shareRead.pics;
                channelNative.sendShareInfo(title, content, link, icon);
            };

            // 设置夜间模式 1夜间  0日间
            window.changeReadMode = function (num) {
                util.chgMode(num);
            };

            // 设置有图像模式 1无图  0有图
            window.changeImgMode = function (num) {
                util.chgImgMode(num);
            };
        }

        /*native接口通信*/
        ChannelDo.prototype.renderPage = function () {
            var t = this;

            //检测是否为夜间模式
            util.checkIfNight();

            //检测是否为无图模式
            util.checkImgMode();

            clientInfo.getRequestParam(function(param){
                channelNative.getChannelInfo(function (data) {
                    t.url = data.url;
                    t.request_param = util.query2obj(t.url);
                    t.request_param.p1=param.p1;
                    t.request_param.gid=param.gid;
                    t.request_param.pid=param.pid;
                    t.loadData(t.page, t.num, t.cursor);
                });
            });
        };

        ChannelDo.prototype.parseNewsData = function (data, type) {
            var newsHtml;
            if (type == "news") {
                newsHtml = util.compileTempl("listView", data);
            } else if (type == "focus") {
                newsHtml = util.compileTempl("focusNews", data);
            }else if(type=="noImg"){
                newsHtml = util.compileTempl("noImgMode", data);
            }
            return newsHtml;
        };

        ChannelDo.prototype.loadData = function (page, num ,cursor) {
            var t = this;
            var item = t.request_param;
            var url= t.url.substring(0,t.url.indexOf("?"));
            var params = {
                channelId: item.channelId,
                num: num,
                imgTag: item.imgTag || "1",
                showPic: item.showPic || "1",
                picScale: item.picScale || "11",
                rt: "json",
                net: item.net,
                cdma_lat: item.cdma_lat,
                cdma_lng: item.cdma_lng,
                from: item.from || "channel",
                page: page,
                action: item.action || "0",
                mode: item.mode || "0",
                cursor: cursor,
                mainFocalId: item.mainFocalId || "0",
                focusPosition: item.focusPosition || "1",
                viceFocalId: item.viceFocalId || "0",
                lastUpdateTime: item.lastUpdateTime || "0",
                p1: item.p1,
                gid: item.gid,
                pid: item.pid || "-1"
            };

            util.sendData("get", url, params, function (data) {

                t.loadingPage.addClass("displayNone");

                if (data) {
                    if (data.shareContent) {
                        t.shareContent = data.shareContent;
                    }

                    if (data.shareRead) {
                        t.shareRead = data.shareRead;
                    }

                    if (data.articles && data.articles.length > 0) {
                        if (t.page == 1) {
                            if (data.articles[0].newsType == 1) {
                                var _focusData = {
                                    "articles": [
                                        data.articles[0]
                                    ]
                                };
                                t.html += t.parseNewsData(_focusData, "focus");
                            }
                            t.html += t.parseNewsData(data, "news");
                            t.termView.html(t.html);
                        } else {
                            t.html = t.parseNewsData(data, "news");
                            t.termView.append(t.html);
                        }
                        for(var len=data.articles.length,i=len-1;i>0;i--){
                            if(data.articles[i]["newsId"] && data.articles[i]["newsType"]!=21){
                                t.cursor=data.articles[i]["newsId"];
                                break;
                            }else{
                                continue;
                            }
                        }
                        t.page++;
                        t.loadingIcon.removeClass("displayNone");
                    }else{
                        clientUI.clientToast("没有更多的数据了哦!");
                        t.loadingIcon.addClass("displayNone");
                    }
                }else{
                    clientUI.clientToast("没有更多的数据了哦!");
                }
            }, function () {

            }, function (xhr, textStatus, errorThrown) {
                clientUI.clientToast("网络好像出现问题了","warn");
                console.log("<section>" + xhr.status + "</section>");
                console.log("<section>" + xhr.readyState + "</section>");
                console.log("<section>" + textStatus + "</section>");
            }, function () {
                t.loadingPage.addClass("displayNone");
            });
        };

        ChannelDo.prototype.bindEvent = function () {
            var t = this;
            //滚动屏幕加载数据
            $(window).on('scroll', function () {
                if (arguments.callee.timer) {
                    clearTimeout(arguments.callee.timer);
                }
                arguments.callee.timer = setTimeout(function () {
                    util.scrollViewer.create("#pageloader", function () {
                        t.loadData(t.page, t.num,t.cursor);
                    });
                }, 600);
            });
        };

        ChannelDo.prototype.init = function () {
            var t = this;
            jsBridgeClient.onDeviceReady(function () {
                t.nativeCallPage();
                t.renderPage();
                t.bindEvent();
            });
        };

        return new ChannelDo();
    });