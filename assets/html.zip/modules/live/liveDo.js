/**
 * Created by huangjian on 15-4-7.
 */
define([
        'bridgeLib',
        'zepto',
        'template',
        'api/client/clientInfo',
        'api/device/platform',
        'live/liveNative',
        'helper/util',
        //自匹配无串参项
        'domReady!'
    ],

    function (bridgeLib, $, template, clientInfo, platform,liveNative, util) {

        function liveDo() {
            this.page = 1;
            this.request_param = {};
            this.loadingPage = $('#loading');
            this.loadingIcon = $("#pageloader");
            this.hisDate = "";
            this.host="";
            this.liveList = "api/live/liveList.go?type=1";   //实时直播数据
            this.hisLivesByDate = "api/live/hisLivesByDate.go";  //历史直播数据
        }

        liveDo.prototype.nativeCallPage = function () {
            var t = this;
            //分享页面
            window.shareChannelPage = function (msg) {
                var title = t.shareRead.title,
                    content = t.shareContent,
                    link = t.shareContent.split(" ")[1],
                    icon = t.shareRead.pics;
                liveNative.sendShareInfo(title, content, link, icon);
            };

            // 设置夜间模式 1夜间  0日间
            window.changeReadMode = function (num) {
                util.chgMode(num);
            };
        }

        liveDo.prototype.setting = function () {
            template.helper('parseToDate', function (time) {
                var _time = util.getLocalTime(time, "MM/dd")
                return _time;
            });

            template.helper('parseToTime', function (time) {
                var _date = util.getLocalTime(time, "hh:mm")
                return _date;
            });

            template.helper('scoreRed', function (score) {
                var _score = score.match(/-/g);
                var _vs = score.match(/vs/gi);
                var _text = "";
                var teamName = score.split(" ");
                if (_score) {
                    _text = score.replace(/-/g, ':');
                }
                else if (_vs) {
                    _text = score.replace(/vs/gi, '<span class="score-red">VS</span>');
                } else {
                    _text = score;
                }
                return _text;
            });
        };

        liveDo.prototype.chgMode = function (num) {
            var ele = document.getElementById("myMode");
            if (ele) {
                if (ele.className == "Mode1") {
                    if (!num) {
                        ele.className = "";
                    }
                    return;
                } else {
                    ele.className = num == "1" ? "Mode1" : "";
                }
            }
        };

        liveDo.prototype.renderPage = function () {
            var t = this;
            //检测是否为夜间模式
            util.checkIfNight();
            clientInfo.getHost(function(host){
                t.host=host.info;
                clientInfo.getRequestParam(function (data) {
                    t.request_param = data;
                    t.loadData(t.request_param);
                });
            });
        };

        liveDo.prototype.parseNewsData = function (id, data) {
            var newsHtml;
            newsHtml = util.compileTempl(id, data);
            return newsHtml;
        };

        liveDo.prototype.loadData = function (request_param) {
            var t = this;

            if (t.page == 1) {
                var liveList= t.host+ t.liveList;
                util.sendData("get", liveList, {}, function (data) {
                    //清除loading
                    t.loadingPage.addClass("displayNone");
                    if(data.todayLives.length>0){
                        var res = t.parseNewsData("liveDoView", data);
                        $("#firstPage").html(res);
                        $("#morePage").removeClass("displayNone");
                        t.hisDate = data.liveDate;
                        t.page++;
                        t.loadingIcon.removeClass("displayNone");
                    }
                });
            } else {
                var hisLivesByDate= t.host+ t.hisLivesByDate;
                var param = {
                    hisDate: t.hisDate,
                    p1: request_param.p1,
                    pid: request_param.pid,
                    gid: request_param.gid
                };
                util.sendData("get", hisLivesByDate, param, function (data) {
                    var forceData = data.response.hisLiveList;
                    var res = t.parseNewsData("liveDateView", data.response);
                    $("#forceLiveNews").append(res);
                    if (forceData.length > 0) {
                        for (var len = forceData.length, i = len; i > 0; i--) {
                            t.hisDate = forceData[i - 1].liveDate;
                            break;
                        }
                    }
                });
            }
        };

        liveDo.prototype.bindEvent = function () {
            var t = this;

            //滚动屏幕加载数据
            $(window).on('scroll', function () {
                if (arguments.callee.timer) {
                    clearTimeout(arguments.callee.timer);
                }
                arguments.callee.timer = setTimeout(function () {
                    util.scrollViewer.create("#pageloader", function () {
                        t.loadData(t.request_param);
                    });
                }, 600);
            });
        };

        liveDo.prototype.init = function () {
            var t = this;
            jsBridgeClient.onDeviceReady(function () {
                t.nativeCallPage();
                t.setting();
                t.renderPage();
                t.bindEvent();
            });
        };

        return new liveDo();

    });