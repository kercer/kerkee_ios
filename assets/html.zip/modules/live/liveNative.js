/**
 * Created by huangjian on 15-4-7.
 */
define(["bridgeLib"],function(bridgeLib){
    function liveNative(){
        this.author='jk';
        this.version="1.0";
        this.jsbc=jsBridgeClient;
        this.nativeCls="channelModule";
    }

    /*
     * @desc 发送当前预览频道的分享信息
     * @param  {String} title
     * @param  {String} content
     * @param  {String} link
     * @param  {String} icon
     */
    liveNative.prototype.sendShareInfo=function(title,content,link,icon){
        var t=this;
        t.jsbc.invoke(t.nativeCls,"sendShareInfo",{
            "title":title,
            "content":content,
            "link":link,
            "icon":icon
        });
    };

    return new liveNative();
});